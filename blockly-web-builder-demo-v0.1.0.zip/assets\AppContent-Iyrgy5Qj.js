import{j as e}from"./react-vendor-Bt4lNSbZ.js";function r(){return e.jsx("div",{className:"app",children:e.jsxs("header",{className:"app-header",children:[e.jsx("h1",{children:"Blockly Web Builder GPT"}),e.jsx("p",{children:"可视化拖拽建站工具，基于 Google Blockly 与 GPT AI 能力。"})]})})}export{r as default};
//# sourceMappingURL=AppContent-Iyrgy5Qj.js.map
